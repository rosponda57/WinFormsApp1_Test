﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1.ClassTest
{
    public class TestAppSettings
    {
        public string Ustawienie1 { get; set; }
        public string Ustawienie2 { get; set; }
        public string Etykieta { get;  set; }
        public string jezyk { get;  set; }
    }
}
