﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1.ClassTest
{
    public class clsDb1: clsBase
    {
        public override void met1()
        {
            MessageBox.Show("clsDb1");
        }
    }
}
